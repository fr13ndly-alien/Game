# How to build DEV

Implement logic Game in StateManager
## run install 

```
npm i
```
## run dev

```
    npm run dev
```
# How to build Release 
```
    npm run build
```