class GameDefine
{
	constructor()
	{
		this.GAME_SPEED_BASE				= 60;
	}
}
module.exports = new GameDefine();